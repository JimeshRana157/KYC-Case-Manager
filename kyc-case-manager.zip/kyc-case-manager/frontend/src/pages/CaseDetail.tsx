import { ChangeEvent, FormEvent, useCallback, useEffect, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { api, errorMessage } from "../api";
import { useAuth } from "../auth";
import { RiskBadge, StatusBadge } from "../components/Badges";
import { AskResult, AuditEntry, CaseDetail, Status, UserItem } from "../types";

// Mirrors the backend workflow (the backend is the source of truth and re-validates everything).
const NEXT: Record<Status, { to: Status; label: string }[]> = {
  PENDING: [{ to: "IN_REVIEW", label: "Start review" }],
  IN_REVIEW: [
    { to: "APPROVED", label: "Approve" },
    { to: "REJECTED", label: "Reject" },
    { to: "PENDING", label: "Send back" },
  ],
  APPROVED: [{ to: "IN_REVIEW", label: "Reopen" }],
  REJECTED: [{ to: "IN_REVIEW", label: "Reopen" }],
};

export default function CaseDetailPage() {
  const { id } = useParams();
  const { user } = useAuth();
  const navigate = useNavigate();
  const isAdmin = user?.role === "admin";

  const [data, setData] = useState<CaseDetail | null>(null);
  const [audit, setAudit] = useState<AuditEntry[]>([]);
  const [users, setUsers] = useState<UserItem[]>([]);
  const [error, setError] = useState("");
  const [note, setNote] = useState("");
  const [docType, setDocType] = useState("ID");
  const [uploading, setUploading] = useState(false);

  const [question, setQuestion] = useState("");
  const [answer, setAnswer] = useState<AskResult | null>(null);
  const [asking, setAsking] = useState(false);

  const load = useCallback(async () => {
    try {
      const [c, a] = await Promise.all([
        api.get<CaseDetail>(`/cases/${id}`),
        api.get<AuditEntry[]>(`/cases/${id}/audit-log`),
      ]);
      setData(c.data);
      setAudit(a.data);
    } catch (err) {
      setError(errorMessage(err));
    }
  }, [id]);

  useEffect(() => {
    void load();
    if (isAdmin) api.get<UserItem[]>("/auth/users").then((r) => setUsers(r.data)).catch(() => undefined);
  }, [load, isAdmin]);

  // Documents are processed in the background: poll until none are pending.
  const hasPending = data?.documents.some((d) => d.status === "PENDING_PROCESSING") ?? false;
  useEffect(() => {
    if (!hasPending) return;
    const timer = setInterval(() => void load(), 1500);
    return () => clearInterval(timer);
  }, [hasPending, load]);

  const run = async (fn: () => Promise<unknown>) => {
    setError("");
    try {
      await fn();
      await load();
    } catch (err) {
      setError(errorMessage(err));
    }
  };

  const changeStatus = (to: Status) =>
    run(async () => {
      await api.patch(`/cases/${id}/status`, { status: to, note: note.trim() || null });
      setNote("");
    });

  const upload = async (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = "";
    if (!file) return;
    setUploading(true);
    const form = new FormData();
    form.append("file", file);
    form.append("doc_type", docType);
    await run(() => api.post(`/cases/${id}/documents`, form));
    setUploading(false);
  };

  const assign = (e: ChangeEvent<HTMLSelectElement>) =>
    run(() => api.patch(`/cases/${id}/assign`, { user_id: e.target.value ? Number(e.target.value) : null }));

  const remove = async () => {
    if (!window.confirm("Delete this case permanently?")) return;
    try {
      await api.delete(`/cases/${id}`);
      navigate("/");
    } catch (err) {
      setError(errorMessage(err));
    }
  };

  const ask = async (e: FormEvent) => {
    e.preventDefault();
    setAsking(true);
    setError("");
    try {
      const { data: res } = await api.post<AskResult>(`/cases/${id}/ask`, { question });
      setAnswer(res);
    } catch (err) {
      setError(errorMessage(err));
    } finally {
      setAsking(false);
    }
  };

  if (!data) return <p className="muted">{error || "Loading…"}</p>;

  return (
    <>
      <p><Link to="/">← All cases</Link></p>
      {error && <div className="error">{error}</div>}

      <section className="card">
        <div className="row spread">
          <div>
            <h1>{data.customer_name}</h1>
            <span className="muted">Case #{data.id}{data.customer_email ? ` · ${data.customer_email}` : ""}</span>
          </div>
          <div className="row">
            <StatusBadge status={data.status} />
            <RiskBadge score={data.risk_score} level={data.risk_level} />
          </div>
        </div>
        <div className="meter"><div className={`meter-fill risk-${data.risk_level}`} style={{ width: `${data.risk_score}%` }} /></div>

        <div className="row" style={{ marginTop: 16 }}>
          {NEXT[data.status].map((n) => (
            <button key={n.to} className={`btn ${n.to === "REJECTED" ? "danger" : n.to === "APPROVED" ? "primary" : ""}`}
                    onClick={() => void changeStatus(n.to)}>{n.label}</button>
          ))}
          <input className="grow" placeholder="Note (required when rejecting)" value={note} onChange={(e) => setNote(e.target.value)} />
        </div>

        {isAdmin && (
          <div className="row" style={{ marginTop: 12 }}>
            <label className="inline">Assign to
              <select value={data.assigned_to ?? ""} onChange={(e) => void assign(e)}>
                <option value="">Unassigned</option>
                {users.map((u) => <option key={u.id} value={u.id}>{u.email}</option>)}
              </select>
            </label>
            <button className="btn danger small" onClick={() => void remove()}>Delete case</button>
          </div>
        )}
        {!isAdmin && data.assignee_email && <p className="muted">Assigned to {data.assignee_email}</p>}
      </section>

      <div className="grid2">
        <section className="card">
          <h2>Risk flags</h2>
          {data.flags.length === 0 ? <p className="muted">No flags raised.</p> : (
            <ul className="flags">
              {data.flags.map((f) => (
                <li key={f.id}>
                  <strong>{f.rule_code}</strong> <span className="badge risk-MEDIUM">+{f.points}</span>
                  <div className="muted">{f.details}</div>
                </li>
              ))}
            </ul>
          )}
        </section>

        <section className="card">
          <h2>Documents</h2>
          <div className="row">
            <select value={docType} onChange={(e) => setDocType(e.target.value)}>
              <option value="ID">ID</option>
              <option value="ADDRESS_PROOF">Address proof</option>
              <option value="OTHER">Other</option>
            </select>
            <input type="file" accept=".pdf,.png,.jpg,.jpeg,.txt" onChange={(e) => void upload(e)} disabled={uploading} />
          </div>
          {data.documents.length === 0 && <p className="muted">No documents uploaded yet.</p>}
          {data.documents.map((d) => (
            <div className="doc" key={d.id}>
              <div className="row spread">
                <strong>{d.filename}</strong>
                <span className={`badge doc-${d.status}`}>{d.status === "PENDING_PROCESSING" ? "PROCESSING…" : d.status}</span>
              </div>
              <div className="muted">{d.doc_type}</div>
              {Object.keys(d.extracted_fields).length > 0 && (
                <dl>
                  {Object.entries(d.extracted_fields).map(([k, v]) => (<div key={k}><dt>{k}</dt><dd>{v}</dd></div>))}
                </dl>
              )}
            </div>
          ))}
        </section>
      </div>

      <section className="card">
        <h2>Ask about this case</h2>
        <form className="row" onSubmit={ask}>
          <input className="grow" required minLength={3} placeholder="e.g. Why was this case flagged?" value={question}
                 onChange={(e) => setQuestion(e.target.value)} />
          <button className="btn primary" disabled={asking}>{asking ? "Thinking…" : "Ask"}</button>
        </form>
        {answer && (
          <div className="answer">
            <pre>{answer.answer}</pre>
            <div className="muted">Answer mode: {answer.mode === "llm" ? "LLM (grounded in sources)" : "extractive (no LLM key configured)"}</div>
            <details>
              <summary>Sources ({answer.sources.length})</summary>
              {answer.sources.map((s) => <p key={s.id}><strong>[{s.id}]</strong> {s.label}: <span className="muted">{s.text}</span></p>)}
            </details>
          </div>
        )}
      </section>

      <section className="card">
        <h2>Audit log</h2>
        <table>
          <thead><tr><th>When</th><th>Who</th><th>Action</th><th>Change</th><th>Note</th></tr></thead>
          <tbody>
            {[...audit].reverse().map((a) => (
              <tr key={a.id}>
                <td className="muted">{new Date(a.timestamp).toLocaleString()}</td>
                <td>{a.user_email ?? "system"}</td>
                <td>{a.action}</td>
                <td>{a.old_status && a.new_status ? `${a.old_status} → ${a.new_status}` : a.new_status ?? ""}</td>
                <td className="muted">{a.note}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </section>
    </>
  );
}
