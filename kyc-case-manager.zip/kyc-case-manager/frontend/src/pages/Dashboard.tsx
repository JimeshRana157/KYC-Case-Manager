import { FormEvent, useCallback, useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { api, errorMessage } from "../api";
import { RiskBadge, StatusBadge } from "../components/Badges";
import { CaseList, Stats } from "../types";

const STATUSES = ["", "PENDING", "IN_REVIEW", "APPROVED", "REJECTED"];

export default function Dashboard() {
  const [stats, setStats] = useState<Stats | null>(null);
  const [list, setList] = useState<CaseList | null>(null);
  const [status, setStatus] = useState("");
  const [riskMin, setRiskMin] = useState(0);
  const [q, setQ] = useState("");
  const [page, setPage] = useState(1);
  const [error, setError] = useState("");

  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [formError, setFormError] = useState("");

  const load = useCallback(async () => {
    try {
      const params: Record<string, string | number> = { page, page_size: 10, risk_min: riskMin };
      if (status) params.status = status;
      if (q.trim()) params.q = q.trim();
      const [s, l] = await Promise.all([api.get<Stats>("/cases/stats"), api.get<CaseList>("/cases", { params })]);
      setStats(s.data);
      setList(l.data);
      setError("");
    } catch (err) {
      setError(errorMessage(err));
    }
  }, [page, status, riskMin, q]);

  useEffect(() => {
    void load();
  }, [load]);

  const createCase = async (e: FormEvent) => {
    e.preventDefault();
    setFormError("");
    try {
      await api.post("/cases", { customer_name: name, customer_email: email || null });
      setName("");
      setEmail("");
      setPage(1);
      await load();
    } catch (err) {
      setFormError(errorMessage(err));
    }
  };

  const pages = list ? Math.max(1, Math.ceil(list.total / list.page_size)) : 1;
  const tiles: [string, number | undefined][] = [
    ["Total", stats?.total], ["Pending", stats?.pending], ["In review", stats?.in_review],
    ["Approved", stats?.approved], ["Rejected", stats?.rejected], ["High risk", stats?.high_risk],
  ];

  return (
    <>
      <section className="tiles">
        {tiles.map(([label, value]) => (
          <div className="tile" key={label}>
            <div className="tile-value">{value ?? "–"}</div>
            <div className="muted">{label}</div>
          </div>
        ))}
      </section>

      <section className="card">
        <h2>New case</h2>
        <form className="row" onSubmit={createCase}>
          <input placeholder="Customer full name" required minLength={2} value={name} onChange={(e) => setName(e.target.value)} />
          <input type="email" placeholder="Customer email (optional)" value={email} onChange={(e) => setEmail(e.target.value)} />
          <button className="btn primary">Create case</button>
        </form>
        {formError && <div className="error">{formError}</div>}
      </section>

      <section className="card">
        <div className="row spread">
          <h2>Cases</h2>
          <div className="row">
            <input placeholder="Search name…" value={q} onChange={(e) => { setQ(e.target.value); setPage(1); }} />
            <select value={status} onChange={(e) => { setStatus(e.target.value); setPage(1); }}>
              {STATUSES.map((s) => <option key={s} value={s}>{s ? s.replace("_", " ") : "All statuses"}</option>)}
            </select>
            <label className="inline">Min risk
              <input type="number" min={0} max={100} value={riskMin} style={{ width: 70 }}
                     onChange={(e) => { setRiskMin(Math.min(100, Math.max(0, Number(e.target.value) || 0))); setPage(1); }} />
            </label>
          </div>
        </div>

        {error && <div className="error">{error}</div>}
        <table>
          <thead>
            <tr><th>#</th><th>Customer</th><th>Status</th><th>Risk</th><th>Assigned</th><th>Created</th></tr>
          </thead>
          <tbody>
            {list?.items.map((c) => (
              <tr key={c.id}>
                <td>{c.id}</td>
                <td><Link to={`/cases/${c.id}`}>{c.customer_name}</Link></td>
                <td><StatusBadge status={c.status} /></td>
                <td><RiskBadge score={c.risk_score} level={c.risk_level} /></td>
                <td className="muted">{c.assignee_email ?? "—"}</td>
                <td className="muted">{new Date(c.created_at).toLocaleString()}</td>
              </tr>
            ))}
            {list && list.items.length === 0 && (
              <tr><td colSpan={6} className="muted center">No cases found</td></tr>
            )}
          </tbody>
        </table>

        <div className="row spread">
          <span className="muted">{list?.total ?? 0} cases</span>
          <div className="row">
            <button className="btn small" disabled={page <= 1} onClick={() => setPage(page - 1)}>Prev</button>
            <span>Page {page} / {pages}</span>
            <button className="btn small" disabled={page >= pages} onClick={() => setPage(page + 1)}>Next</button>
          </div>
        </div>
      </section>
    </>
  );
}
