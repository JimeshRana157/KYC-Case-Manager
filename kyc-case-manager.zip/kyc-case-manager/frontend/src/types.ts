export type Status = "PENDING" | "IN_REVIEW" | "APPROVED" | "REJECTED";
export type RiskLevel = "LOW" | "MEDIUM" | "HIGH";

export interface Case {
  id: number;
  customer_name: string;
  customer_email: string | null;
  status: Status;
  risk_score: number;
  risk_level: RiskLevel;
  assigned_to: number | null;
  assignee_email: string | null;
  created_at: string;
}

export interface DocumentItem {
  id: number;
  filename: string;
  doc_type: string;
  status: "PENDING_PROCESSING" | "PROCESSED" | "FAILED";
  extracted_fields: Record<string, string>;
  created_at: string;
}

export interface Flag {
  id: number;
  rule_code: string;
  points: number;
  details: string;
}

export interface CaseDetail extends Case {
  documents: DocumentItem[];
  flags: Flag[];
}

export interface AuditEntry {
  id: number;
  action: string;
  old_status: Status | null;
  new_status: Status | null;
  note: string | null;
  user_email: string | null;
  timestamp: string;
}

export interface CaseList {
  items: Case[];
  total: number;
  page: number;
  page_size: number;
}

export interface Stats {
  total: number;
  pending: number;
  in_review: number;
  approved: number;
  rejected: number;
  high_risk: number;
}

export interface UserItem {
  id: number;
  email: string;
  role: string;
}

export interface AskResult {
  answer: string;
  sources: { id: string; label: string; text: string }[];
  mode: "llm" | "extractive";
}
