import { RiskLevel, Status } from "../types";

export function StatusBadge({ status }: { status: Status }) {
  return <span className={`badge status-${status}`}>{status.replace("_", " ")}</span>;
}

export function RiskBadge({ score, level }: { score: number; level: RiskLevel }) {
  return (
    <span className={`badge risk-${level}`} title={`Risk score ${score}/100`}>
      {level} · {score}
    </span>
  );
}
