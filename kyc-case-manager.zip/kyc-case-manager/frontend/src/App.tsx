import { ReactNode } from "react";
import { Link, Navigate, Route, Routes, useNavigate } from "react-router-dom";
import { useAuth } from "./auth";
import CaseDetailPage from "./pages/CaseDetail";
import Dashboard from "./pages/Dashboard";
import Login from "./pages/Login";

function Protected({ children }: { children: ReactNode }) {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  if (!user) return <Navigate to="/login" replace />;
  return (
    <>
      <header className="topbar">
        <Link to="/" className="brand">KYC Case Manager</Link>
        <div className="topbar-right">
          <span className="muted">{user.email} · {user.role}</span>
          <button className="btn small" onClick={() => { logout(); navigate("/login"); }}>Log out</button>
        </div>
      </header>
      <main className="container">{children}</main>
    </>
  );
}

export default function App() {
  return (
    <Routes>
      <Route path="/login" element={<Login />} />
      <Route path="/" element={<Protected><Dashboard /></Protected>} />
      <Route path="/cases/:id" element={<Protected><CaseDetailPage /></Protected>} />
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}
