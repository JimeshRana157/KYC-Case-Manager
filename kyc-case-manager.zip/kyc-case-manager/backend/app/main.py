import logging
from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy import select

from app.config import settings
from app.database import SessionLocal
from app.models import Role, User
from app.routers import auth, cases, documents
from app.security import hash_password
from app.services.risk import RULES
from app.services.sanctions import seed_sanctions

logger = logging.getLogger(__name__)


def seed_admin() -> None:
    if not (settings.admin_email and settings.admin_password):
        return
    with SessionLocal() as db:
        email = settings.admin_email.lower()
        if db.scalar(select(User).where(User.email == email)) is None:
            db.add(User(email=email, password_hash=hash_password(settings.admin_password), role=Role.ADMIN.value))
            db.commit()
            logger.info("Created admin user %s", email)


@asynccontextmanager
async def lifespan(_: FastAPI):
    # Tables are created by Alembic (`alembic upgrade head`), not here.
    seed_admin()
    with SessionLocal() as db:
        seed_sanctions(db)
    yield


app = FastAPI(
    title="KYC Case Manager",
    description="AI-assisted KYC case management: document extraction, rule-based risk scoring, review workflow.",
    version="1.0.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=[o.strip() for o in settings.cors_origins.split(",") if o.strip()],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(auth.router)
app.include_router(cases.router)
app.include_router(documents.router)


@app.get("/health", tags=["meta"])
def health():
    return {"status": "ok"}


@app.get("/rules", tags=["meta"])
def list_rules():
    """The risk rules and their points, so the UI/README never drift from the code."""
    return [{"code": code, "points": pts, "description": desc} for code, (pts, desc) in RULES.items()]
