from datetime import datetime

from pydantic import BaseModel, ConfigDict, EmailStr, Field

from app.models import CaseStatus


class ORM(BaseModel):
    model_config = ConfigDict(from_attributes=True)


# ---------- auth ----------
class UserCreate(BaseModel):
    email: EmailStr
    password: str = Field(min_length=8, max_length=72)


class UserOut(ORM):
    id: int
    email: str
    role: str


class Token(BaseModel):
    access_token: str
    token_type: str = "bearer"
    email: str
    role: str


# ---------- cases ----------
class CaseCreate(BaseModel):
    customer_name: str = Field(min_length=2, max_length=255)
    customer_email: EmailStr | None = None


class DocumentOut(ORM):
    id: int
    filename: str
    doc_type: str
    status: str
    extracted_fields: dict
    created_at: datetime


class FlagOut(ORM):
    id: int
    rule_code: str
    points: int
    details: str


class AuditOut(ORM):
    id: int
    action: str
    old_status: str | None
    new_status: str | None
    note: str | None
    user_email: str | None
    timestamp: datetime


class CaseOut(ORM):
    id: int
    customer_name: str
    customer_email: str | None
    status: str
    risk_score: int
    risk_level: str
    assigned_to: int | None
    assignee_email: str | None
    created_at: datetime


class CaseDetail(CaseOut):
    documents: list[DocumentOut]
    flags: list[FlagOut]


class CaseList(BaseModel):
    items: list[CaseOut]
    total: int
    page: int
    page_size: int


class StatusUpdate(BaseModel):
    status: CaseStatus
    note: str | None = Field(default=None, max_length=2000)


class AssignUpdate(BaseModel):
    user_id: int | None


class Stats(BaseModel):
    total: int
    pending: int
    in_review: int
    approved: int
    rejected: int
    high_risk: int


# ---------- Q&A ----------
class AskRequest(BaseModel):
    question: str = Field(min_length=3, max_length=500)


class Source(BaseModel):
    id: str
    label: str
    text: str


class AskResponse(BaseModel):
    answer: str
    sources: list[Source]
    mode: str  # "llm" | "extractive"
