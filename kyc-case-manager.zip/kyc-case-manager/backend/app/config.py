from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    database_url: str = "postgresql+psycopg2://kyc:kyc@localhost:5432/kyc"
    jwt_secret: str = "change-me-in-production"
    jwt_algorithm: str = "HS256"
    access_token_minutes: int = 60

    upload_dir: str = "uploads"
    max_upload_mb: int = 5

    # Optional: an admin account created on startup
    admin_email: str | None = None
    admin_password: str | None = None

    # Optional: enables LLM answers in "Ask about this case".
    # Without a key the app falls back to extractive answers (no API call).
    anthropic_api_key: str | None = None
    llm_model: str = "claude-sonnet-5-5"

    cors_origins: str = "http://localhost:5173"

    model_config = SettingsConfigDict(env_file=".env", extra="ignore")


settings = Settings()
