import uuid
from pathlib import Path

from fastapi import APIRouter, BackgroundTasks, Depends, File, Form, HTTPException, UploadFile, status
from sqlalchemy.orm import Session

from app.config import settings
from app.database import get_db
from app.deps import get_current_user
from app.models import Document, User
from app.routers.cases import get_case_or_404
from app.schemas import DocumentOut
from app.services.audit import log_event
from app.services.pipeline import process_document

router = APIRouter(prefix="/cases", tags=["documents"])

ALLOWED_EXTENSIONS = {".pdf", ".png", ".jpg", ".jpeg", ".txt"}
DOC_TYPES = {"ID", "ADDRESS_PROOF", "OTHER"}


@router.post("/{case_id}/documents", response_model=DocumentOut, status_code=status.HTTP_201_CREATED)
async def upload_document(
    case_id: int,
    background: BackgroundTasks,
    file: UploadFile = File(...),
    doc_type: str = Form("ID"),
    user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    case = get_case_or_404(db, case_id)

    suffix = Path(file.filename or "").suffix.lower()
    if suffix not in ALLOWED_EXTENSIONS:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, f"Unsupported file type. Allowed: {sorted(ALLOWED_EXTENSIONS)}")
    if doc_type not in DOC_TYPES:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, f"doc_type must be one of {sorted(DOC_TYPES)}")

    content = await file.read()
    if len(content) > settings.max_upload_mb * 1024 * 1024:
        raise HTTPException(413, f"File larger than {settings.max_upload_mb} MB")
    if not content:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "File is empty")

    upload_dir = Path(settings.upload_dir)
    upload_dir.mkdir(parents=True, exist_ok=True)
    # Never trust the client filename for the on-disk name (path traversal); keep it only for display.
    stored_path = upload_dir / f"{uuid.uuid4().hex}{suffix}"
    stored_path.write_bytes(content)

    doc = Document(case_id=case.id, filename=Path(file.filename).name, file_path=str(stored_path), doc_type=doc_type)
    db.add(doc)
    db.flush()
    log_event(db, case.id, "DOCUMENT_UPLOADED", user_id=user.id, note=doc.filename)
    db.commit()

    background.add_task(process_document, doc.id)
    return doc
