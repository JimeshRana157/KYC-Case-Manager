from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.database import get_db
from app.deps import get_current_user, require_admin
from app.models import Case, CaseStatus, Role, User
from app.schemas import (
    AssignUpdate, AskRequest, AskResponse, AuditOut, CaseCreate, CaseDetail, CaseList, CaseOut,
    FlagOut, Stats, StatusUpdate,
)
from app.services import qa
from app.services.audit import log_event
from app.services.pipeline import evaluate_case

router = APIRouter(prefix="/cases", tags=["cases"])

S = CaseStatus
TRANSITIONS: dict[str, set[str]] = {
    S.PENDING.value: {S.IN_REVIEW.value},
    S.IN_REVIEW.value: {S.APPROVED.value, S.REJECTED.value, S.PENDING.value},
    S.APPROVED.value: {S.IN_REVIEW.value},
    S.REJECTED.value: {S.IN_REVIEW.value},
}
FINAL = {S.APPROVED.value, S.REJECTED.value}


def get_case_or_404(db: Session, case_id: int) -> Case:
    case = db.get(Case, case_id)
    if case is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Case not found")
    return case


@router.post("", response_model=CaseOut, status_code=status.HTTP_201_CREATED)
def create_case(payload: CaseCreate, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    case = Case(customer_name=payload.customer_name.strip(), customer_email=payload.customer_email, created_by=user.id)
    db.add(case)
    db.flush()
    log_event(db, case.id, "CASE_CREATED", user_id=user.id, new_status=case.status)
    db.commit()
    return case


@router.get("", response_model=CaseList)
def list_cases(
    status_filter: CaseStatus | None = Query(default=None, alias="status"),
    risk_min: int = Query(default=0, ge=0, le=100),
    q: str | None = Query(default=None, max_length=100),
    page: int = Query(default=1, ge=1),
    page_size: int = Query(default=10, ge=1, le=100),
    _: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    query = select(Case).where(Case.risk_score >= risk_min)
    if status_filter:
        query = query.where(Case.status == status_filter.value)
    if q:
        query = query.where(Case.customer_name.ilike(f"%{q}%"))
    total = db.scalar(select(func.count()).select_from(query.subquery())) or 0
    items = db.scalars(
        query.order_by(Case.created_at.desc(), Case.id.desc()).offset((page - 1) * page_size).limit(page_size)
    ).all()
    return CaseList(items=items, total=total, page=page, page_size=page_size)


@router.get("/stats", response_model=Stats)
def stats(_: User = Depends(get_current_user), db: Session = Depends(get_db)):
    counts = dict(db.execute(select(Case.status, func.count()).group_by(Case.status)).all())
    high = db.scalar(select(func.count()).select_from(Case).where(Case.risk_level == "HIGH")) or 0
    return Stats(
        total=sum(counts.values()),
        pending=counts.get(S.PENDING.value, 0),
        in_review=counts.get(S.IN_REVIEW.value, 0),
        approved=counts.get(S.APPROVED.value, 0),
        rejected=counts.get(S.REJECTED.value, 0),
        high_risk=high,
    )


@router.get("/{case_id}", response_model=CaseDetail)
def get_case(case_id: int, _: User = Depends(get_current_user), db: Session = Depends(get_db)):
    return get_case_or_404(db, case_id)


@router.get("/{case_id}/flags", response_model=list[FlagOut])
def get_flags(case_id: int, _: User = Depends(get_current_user), db: Session = Depends(get_db)):
    return get_case_or_404(db, case_id).flags


@router.get("/{case_id}/audit-log", response_model=list[AuditOut])
def get_audit_log(case_id: int, _: User = Depends(get_current_user), db: Session = Depends(get_db)):
    return get_case_or_404(db, case_id).audit_logs


@router.patch("/{case_id}/status", response_model=CaseOut)
def update_status(
    case_id: int, payload: StatusUpdate, user: User = Depends(get_current_user), db: Session = Depends(get_db)
):
    case = get_case_or_404(db, case_id)
    old, new = case.status, payload.status.value

    if new not in TRANSITIONS[old]:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, f"Cannot move a case from {old} to {new}")
    if old in FINAL and user.role != Role.ADMIN.value:
        raise HTTPException(status.HTTP_403_FORBIDDEN, "Only an admin can reopen a decided case")
    if new == S.APPROVED.value and case.risk_level == "HIGH" and user.role != Role.ADMIN.value:
        raise HTTPException(status.HTTP_403_FORBIDDEN, "High-risk cases can only be approved by an admin")
    if new == S.REJECTED.value and not (payload.note and payload.note.strip()):
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "A note is required when rejecting a case")

    case.status = new
    log_event(db, case.id, "STATUS_CHANGED", user_id=user.id, old_status=old, new_status=new, note=payload.note)
    db.commit()
    return case


@router.patch("/{case_id}/assign", response_model=CaseOut)
def assign_case(
    case_id: int, payload: AssignUpdate, admin: User = Depends(require_admin), db: Session = Depends(get_db)
):
    case = get_case_or_404(db, case_id)
    assignee = None
    if payload.user_id is not None:
        assignee = db.get(User, payload.user_id)
        if assignee is None:
            raise HTTPException(status.HTTP_404_NOT_FOUND, "User not found")
    case.assigned_to = payload.user_id
    case.assignee = assignee
    log_event(db, case.id, "ASSIGNED", user_id=admin.id, note=f"Assigned to {assignee.email if assignee else 'nobody'}")
    db.commit()
    return case


@router.post("/{case_id}/evaluate", response_model=CaseDetail)
def re_evaluate(case_id: int, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    """Re-run the rule engine (e.g. after the sanctions list changed)."""
    case = get_case_or_404(db, case_id)
    evaluate_case(db, case)
    log_event(db, case.id, "RE_EVALUATED", user_id=user.id, note=f"risk {case.risk_score} ({case.risk_level})")
    db.commit()
    return case


@router.post("/{case_id}/ask", response_model=AskResponse)
def ask_about_case(
    case_id: int, payload: AskRequest, _: User = Depends(get_current_user), db: Session = Depends(get_db)
):
    return qa.ask(get_case_or_404(db, case_id), payload.question)


@router.delete("/{case_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_case(case_id: int, _: User = Depends(require_admin), db: Session = Depends(get_db)):
    case = get_case_or_404(db, case_id)
    db.delete(case)
    db.commit()
