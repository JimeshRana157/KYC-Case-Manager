"""Text extraction from uploaded documents and parsing of KYC fields."""
import logging
import re
from datetime import date, datetime
from pathlib import Path

logger = logging.getLogger(__name__)

DATE_FORMATS = ("%Y-%m-%d", "%d/%m/%Y", "%d-%m-%Y", "%d.%m.%Y", "%d %b %Y", "%d %B %Y", "%b %d, %Y")


def parse_date(value: str | None) -> date | None:
    if not value:
        return None
    value = value.strip()
    for fmt in DATE_FORMATS:
        try:
            return datetime.strptime(value, fmt).date()
        except ValueError:
            continue
    return None


def extract_text(path: str) -> str:
    """Return the text content of a PDF, image (via OCR) or plain-text file."""
    suffix = Path(path).suffix.lower()
    if suffix == ".txt":
        return Path(path).read_text(encoding="utf-8", errors="ignore")
    if suffix == ".pdf":
        import pdfplumber

        with pdfplumber.open(path) as pdf:
            return "\n".join((page.extract_text() or "") for page in pdf.pages)
    if suffix in {".png", ".jpg", ".jpeg"}:
        try:
            import pytesseract
            from PIL import Image

            return pytesseract.image_to_string(Image.open(path))
        except Exception as exc:  # tesseract binary missing, corrupt image, ...
            logger.warning("OCR failed for %s: %s", path, exc)
            raise RuntimeError("OCR is not available or the image could not be read") from exc
    raise ValueError(f"Unsupported file type: {suffix}")


_PATTERNS = {
    "name": r"^\s*(?:full\s+)?name\s*[:\-]\s*(.+?)\s*$",
    "dob": r"^\s*(?:date\s+of\s+birth|dob|birth\s+date)\s*[:\-]\s*(.+?)\s*$",
    "id_number": r"^\s*(?:id|document|passport|licen[sc]e)\s*(?:number|no\.?|#)\s*[:\-]\s*([A-Za-z0-9\- ]+?)\s*$",
    "expiry": r"^\s*(?:expiry(?:\s+date)?|date\s+of\s+expiry|valid\s+until|expires)\s*[:\-]\s*(.+?)\s*$",
}


def parse_fields(text: str) -> dict:
    """Pull name / DOB / ID number / expiry out of free text. Dates are normalised to ISO."""
    fields: dict = {}
    for key, pattern in _PATTERNS.items():
        match = re.search(pattern, text, flags=re.IGNORECASE | re.MULTILINE)
        if not match:
            continue
        value = match.group(1).strip()
        if key in {"dob", "expiry"}:
            parsed = parse_date(value)
            if parsed is None:
                continue
            value = parsed.isoformat()
        fields[key] = value
    return fields
