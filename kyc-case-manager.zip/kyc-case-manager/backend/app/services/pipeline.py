"""Document processing pipeline: extract -> parse -> evaluate risk. Runs as a background task."""
import logging

from sqlalchemy.orm import Session

from app.database import SessionLocal
from app.models import Case, Document, RiskFlag
from app.services import risk, sanctions
from app.services.audit import log_event
from app.services.extraction import extract_text, parse_fields

logger = logging.getLogger(__name__)


def evaluate_case(db: Session, case: Case) -> None:
    """Recompute flags and the risk score for a case from its processed documents."""
    docs = [(d.filename, d.extracted_fields or {}) for d in case.documents if d.status == "PROCESSED"]
    flags = risk.evaluate(case.customer_name, docs, sanctions.all_names(db))
    case.flags.clear()
    for f in flags:
        case.flags.append(RiskFlag(rule_code=f.rule_code, points=f.points, details=f.details))
    case.risk_score, case.risk_level = risk.score_flags(flags)


def process_document(document_id: int) -> None:
    """Background task. Uses its own DB session because the request session is already closed."""
    db = SessionLocal()
    try:
        doc = db.get(Document, document_id)
        if doc is None:
            return
        try:
            doc.raw_text = extract_text(doc.file_path)
            doc.extracted_fields = parse_fields(doc.raw_text)
            doc.status = "PROCESSED"
        except Exception as exc:
            logger.exception("Processing failed for document %s", document_id)
            doc.status = "FAILED"
            log_event(db, doc.case_id, "DOCUMENT_FAILED", note=f"{doc.filename}: {exc}")
            db.commit()
            return

        case = db.get(Case, doc.case_id)
        evaluate_case(db, case)
        log_event(db, case.id, "DOCUMENT_PROCESSED",
                  note=f"{doc.filename} -> risk {case.risk_score} ({case.risk_level})")
        db.commit()
    finally:
        db.close()
