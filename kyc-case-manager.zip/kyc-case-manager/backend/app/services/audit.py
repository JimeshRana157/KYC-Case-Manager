from sqlalchemy.orm import Session

from app.models import AuditLog


def log_event(
    db: Session,
    case_id: int,
    action: str,
    user_id: int | None = None,
    old_status: str | None = None,
    new_status: str | None = None,
    note: str | None = None,
) -> None:
    db.add(
        AuditLog(case_id=case_id, user_id=user_id, action=action,
                 old_status=old_status, new_status=new_status, note=note)
    )
