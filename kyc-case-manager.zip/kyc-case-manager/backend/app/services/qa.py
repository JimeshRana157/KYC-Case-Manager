"""'Ask about this case': retrieval over ONE case's data, answers grounded in cited sources.

Retrieval: BM25 (own small implementation, positive IDF so tiny corpora work) over small chunks (case summary, risk flags, document fields, document text).
Generation: an LLM if ANTHROPIC_API_KEY is set, otherwise an extractive fallback.
The LLM only ever sees the retrieved chunks of this single case, which limits hallucination.
"""
import logging
import math
import re
from collections import Counter

from app.config import settings
from app.models import Case

logger = logging.getLogger(__name__)
TOP_K = 4

SYSTEM_PROMPT = (
    "You are an assistant for a KYC compliance reviewer. Answer the question using ONLY the sources provided. "
    "Cite sources inline like [S1]. If the sources do not contain the answer, say you cannot find it in the case data. "
    "Do not give a final approve/reject decision; the human reviewer decides."
)


STOPWORDS = {"a", "an", "the", "is", "are", "was", "were", "what", "why", "how", "of", "to", "in", "on", "for",
             "this", "that", "it", "does", "do", "did", "and", "or", "me", "tell", "about", "case"}


def _tokens(text: str) -> list[str]:
    return [t for t in re.findall(r"[a-z0-9]+", text.lower()) if t not in STOPWORDS]


def bm25_scores(query: list[str], docs: list[list[str]], k1: float = 1.5, b: float = 0.75) -> list[float]:
    """Okapi BM25 with the Lucene IDF variant, log(1 + (N-n+0.5)/(n+0.5)), which is always > 0."""
    n_docs = len(docs)
    avg_len = (sum(len(d) for d in docs) / n_docs) or 1.0
    doc_freq = Counter(term for d in docs for term in set(d))
    scores = []
    for d in docs:
        tf, score = Counter(d), 0.0
        for term in set(query):
            if term not in tf:
                continue
            idf = math.log(1 + (n_docs - doc_freq[term] + 0.5) / (doc_freq[term] + 0.5))
            score += idf * tf[term] * (k1 + 1) / (tf[term] + k1 * (1 - b + b * len(d) / avg_len))
        scores.append(score)
    return scores


def build_chunks(case: Case) -> list[dict]:
    flags_txt = "; ".join(f"{f.rule_code} (+{f.points}): {f.details}" for f in case.flags) or "none"
    chunks = [{
        "label": "Case summary",
        "text": (f"Customer {case.customer_name}. Status {case.status}. Risk score {case.risk_score}/100 "
                 f"({case.risk_level}). Risk flags: {flags_txt}."),
    }]
    for doc in case.documents:
        if doc.extracted_fields:
            fields = ", ".join(f"{k}={v}" for k, v in doc.extracted_fields.items())
            chunks.append({"label": f"{doc.filename} - extracted fields", "text": fields})
        lines = [ln.strip() for ln in (doc.raw_text or "").splitlines() if ln.strip()]
        for i in range(0, len(lines), 3):
            chunks.append({"label": f"{doc.filename} - text", "text": " ".join(lines[i:i + 3])})
    for n, c in enumerate(chunks, start=1):
        c["id"] = f"S{n}"
    return chunks


def retrieve(question: str, chunks: list[dict], k: int = TOP_K) -> list[dict]:
    """Always keep the case summary (S1), then add the best BM25 matches."""
    summary, rest = chunks[0], chunks[1:]
    if not rest:
        return [summary]
    scores = bm25_scores(_tokens(question), [_tokens(c["text"]) for c in rest])
    ranked = sorted(zip(scores, rest), key=lambda pair: pair[0], reverse=True)
    picked = [c for s, c in ranked[: k - 1] if s > 0]
    return [summary] + picked


def _extractive(sources: list[dict]) -> str:
    lines = [f"- [{s['id']}] {s['text']}" for s in sources]
    return "Most relevant information found in this case:\n" + "\n".join(lines)


def _llm_answer(question: str, sources: list[dict]) -> str:
    import anthropic

    context = "\n".join(f"[{s['id']}] ({s['label']}) {s['text']}" for s in sources)
    client = anthropic.Anthropic(api_key=settings.anthropic_api_key)
    response = client.messages.create(
        model=settings.llm_model,
        max_tokens=500,
        system=SYSTEM_PROMPT,
        messages=[{"role": "user", "content": f"Sources:\n{context}\n\nQuestion: {question}"}],
    )
    return "".join(block.text for block in response.content if getattr(block, "text", None)).strip()


def ask(case: Case, question: str) -> dict:
    sources = retrieve(question, build_chunks(case))
    mode, answer = "extractive", None
    if settings.anthropic_api_key:
        try:
            answer, mode = _llm_answer(question, sources), "llm"
        except Exception as exc:  # network error, bad key, quota... never break the endpoint
            logger.warning("LLM call failed, using extractive answer: %s", exc)
    if answer is None:
        answer = _extractive(sources)
    return {"answer": answer, "sources": sources, "mode": mode}
