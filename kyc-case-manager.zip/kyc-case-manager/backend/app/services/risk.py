"""Rule-based risk engine. Pure functions: easy to unit-test, no DB access."""
import re
from dataclasses import dataclass
from datetime import date

from rapidfuzz import fuzz

from app.services.extraction import parse_date

NAME_MISMATCH_THRESHOLD = 85  # similarity below this => mismatch
SANCTIONS_THRESHOLD = 90  # similarity at/above this => potential match
MIN_AGE = 18

# code -> (points, human description). Exposed via GET /rules and in the README.
RULES: dict[str, tuple[int, str]] = {
    "SANCTIONS_MATCH": (60, "Name closely matches an entry on the sanctions list"),
    "DOC_EXPIRED": (30, "An identity document is past its expiry date"),
    "NAME_MISMATCH": (25, "Name on a document differs from the customer name on the case"),
    "UNDERAGE": (20, f"Date of birth indicates the customer is under {MIN_AGE}"),
    "MISSING_FIELDS": (10, "A document is missing its ID number or date of birth"),
}


@dataclass
class Flag:
    rule_code: str
    points: int
    details: str


def normalize_name(name: str) -> str:
    name = re.sub(r"[^\w\s]", " ", name.lower())
    return re.sub(r"\s+", " ", name).strip()


def name_similarity(a: str, b: str) -> float:
    return fuzz.token_sort_ratio(normalize_name(a), normalize_name(b))


def _age(dob: date, today: date) -> int:
    return today.year - dob.year - ((today.month, today.day) < (dob.month, dob.day))


def evaluate(
    customer_name: str,
    documents: list[tuple[str, dict]],
    sanctions_names: list[str],
    today: date | None = None,
) -> list[Flag]:
    """documents is a list of (filename, extracted_fields)."""
    today = today or date.today()
    expired, mismatched, missing, underage = [], [], [], []
    names_to_screen = {customer_name}

    for filename, fields in documents:
        doc_name = fields.get("name")
        if doc_name:
            names_to_screen.add(doc_name)
            score = name_similarity(customer_name, doc_name)
            if score < NAME_MISMATCH_THRESHOLD:
                mismatched.append(f"{filename}: '{doc_name}' vs '{customer_name}' ({score:.0f}% similar)")

        expiry = parse_date(fields.get("expiry"))
        if expiry and expiry < today:
            expired.append(f"{filename}: expired on {expiry.isoformat()}")

        dob = parse_date(fields.get("dob"))
        if dob and _age(dob, today) < MIN_AGE:
            underage.append(f"{filename}: date of birth {dob.isoformat()}")

        if not fields.get("id_number") or not fields.get("dob"):
            missing.append(filename)

    flags: list[Flag] = []

    best: tuple[float, str, str] | None = None  # (score, screened name, sanctions entry)
    for candidate in names_to_screen:
        for entry in sanctions_names:
            score = name_similarity(candidate, entry)
            if score >= SANCTIONS_THRESHOLD and (best is None or score > best[0]):
                best = (score, candidate, entry)
    if best:
        flags.append(
            Flag("SANCTIONS_MATCH", RULES["SANCTIONS_MATCH"][0],
                 f"'{best[1]}' matches sanctions entry '{best[2]}' ({best[0]:.0f}% similar)")
        )
    if expired:
        flags.append(Flag("DOC_EXPIRED", RULES["DOC_EXPIRED"][0], "; ".join(expired)))
    if mismatched:
        flags.append(Flag("NAME_MISMATCH", RULES["NAME_MISMATCH"][0], "; ".join(mismatched)))
    if underage:
        flags.append(Flag("UNDERAGE", RULES["UNDERAGE"][0], "; ".join(underage)))
    if missing:
        flags.append(Flag("MISSING_FIELDS", RULES["MISSING_FIELDS"][0], "Missing ID number or DOB in: " + ", ".join(missing)))
    return flags


def score_flags(flags: list[Flag]) -> tuple[int, str]:
    """Sum of points, capped at 100, mapped to LOW / MEDIUM / HIGH."""
    score = min(100, sum(f.points for f in flags))
    if score >= 60:
        level = "HIGH"
    elif score >= 30:
        level = "MEDIUM"
    else:
        level = "LOW"
    return score, level
