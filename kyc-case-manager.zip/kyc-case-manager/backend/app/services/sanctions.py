import csv
from pathlib import Path

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.models import SanctionsEntry

SAMPLE_CSV = Path(__file__).resolve().parent.parent / "data" / "sanctions_sample.csv"


def seed_sanctions(db: Session, csv_path: Path = SAMPLE_CSV) -> int:
    """Load the (fictional) sample sanctions list if the table is empty."""
    if db.scalar(select(func.count()).select_from(SanctionsEntry)):
        return 0
    with open(csv_path, newline="", encoding="utf-8") as fh:
        rows = [SanctionsEntry(name=r["name"], source=r["source"], country=r["country"]) for r in csv.DictReader(fh)]
    db.add_all(rows)
    db.commit()
    return len(rows)


def all_names(db: Session) -> list[str]:
    return list(db.scalars(select(SanctionsEntry.name)))
