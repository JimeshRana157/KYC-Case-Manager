from sqlalchemy import create_engine
from sqlalchemy.orm import DeclarativeBase, sessionmaker
from sqlalchemy.pool import QueuePool, StaticPool

from app.config import settings

_is_sqlite = settings.database_url.startswith("sqlite")

if _is_sqlite:
    # SQLite is only for tests / quick local runs; production uses PostgreSQL.
    in_memory = settings.database_url in ("sqlite://", "sqlite:///:memory:")
    engine = create_engine(
        settings.database_url,
        connect_args={"check_same_thread": False},
        # In-memory DBs vanish per connection, so tests share ONE connection (StaticPool).
        # File DBs must use a real pool: sharing one connection across request threads is unsafe.
        poolclass=StaticPool if in_memory else QueuePool,
    )
else:
    engine = create_engine(settings.database_url, pool_pre_ping=True)

SessionLocal = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)


class Base(DeclarativeBase):
    pass


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
