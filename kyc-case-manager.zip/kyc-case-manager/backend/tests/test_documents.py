import io

from app.config import settings
from tests.conftest import create_case, upload_sample


def flag_codes(client, headers, cid):
    return {f["rule_code"] for f in client.get(f"/cases/{cid}/flags", headers=headers).json()}


def test_valid_document_is_processed_with_no_flags(client, reviewer):
    cid = create_case(client, reviewer)["id"]
    res = upload_sample(client, reviewer, cid, "valid_id.txt")
    assert res.status_code == 201

    detail = client.get(f"/cases/{cid}", headers=reviewer).json()
    doc = detail["documents"][0]
    assert doc["status"] == "PROCESSED"
    assert doc["extracted_fields"]["id_number"] == "EX-4821-7730"
    assert doc["extracted_fields"]["dob"] == "1999-03-14"  # normalised from 14/03/1999
    assert (detail["risk_score"], detail["risk_level"], detail["flags"]) == (0, "LOW", [])


def test_expired_document_raises_flag(client, reviewer):
    cid = create_case(client, reviewer)["id"]
    upload_sample(client, reviewer, cid, "expired_id.txt")
    detail = client.get(f"/cases/{cid}", headers=reviewer).json()
    assert flag_codes(client, reviewer, cid) == {"DOC_EXPIRED"}
    assert (detail["risk_score"], detail["risk_level"]) == (30, "MEDIUM")


def test_name_mismatch(client, reviewer):
    cid = create_case(client, reviewer)["id"]
    upload_sample(client, reviewer, cid, "name_mismatch_id.txt")
    assert flag_codes(client, reviewer, cid) == {"NAME_MISMATCH"}


def test_sanctions_hit_is_high_risk(client, reviewer):
    cid = create_case(client, reviewer, "Rodrigo Valmont Estrada")["id"]
    upload_sample(client, reviewer, cid, "sanctions_hit_id.txt")
    detail = client.get(f"/cases/{cid}", headers=reviewer).json()
    assert flag_codes(client, reviewer, cid) == {"SANCTIONS_MATCH"}
    assert (detail["risk_score"], detail["risk_level"]) == (60, "HIGH")


def test_multiple_documents_are_combined_and_flags_not_duplicated(client, reviewer):
    cid = create_case(client, reviewer)["id"]
    upload_sample(client, reviewer, cid, "expired_id.txt")
    upload_sample(client, reviewer, cid, "address_proof.txt", doc_type="ADDRESS_PROOF")
    detail = client.get(f"/cases/{cid}", headers=reviewer).json()
    assert len(detail["documents"]) == 2
    assert {f["rule_code"] for f in detail["flags"]} == {"DOC_EXPIRED", "MISSING_FIELDS"}
    assert detail["risk_score"] == 40
    # Re-evaluating must replace flags, not append
    again = client.post(f"/cases/{cid}/evaluate", headers=reviewer).json()
    assert len(again["flags"]) == 2


def test_upload_rejects_bad_type_empty_and_unknown_case(client, reviewer):
    cid = create_case(client, reviewer)["id"]
    bad = client.post(f"/cases/{cid}/documents", files={"file": ("virus.exe", b"MZ", "application/octet-stream")}, headers=reviewer)
    assert bad.status_code == 400
    empty = client.post(f"/cases/{cid}/documents", files={"file": ("a.txt", b"", "text/plain")}, headers=reviewer)
    assert empty.status_code == 400
    bad_type = client.post(f"/cases/{cid}/documents", files={"file": ("a.txt", b"x", "text/plain")},
                           data={"doc_type": "NOPE"}, headers=reviewer)
    assert bad_type.status_code == 400
    missing = client.post("/cases/999/documents", files={"file": ("a.txt", b"x", "text/plain")}, headers=reviewer)
    assert missing.status_code == 404


def test_upload_too_large(client, reviewer, monkeypatch):
    monkeypatch.setattr(settings, "max_upload_mb", 0)
    cid = create_case(client, reviewer)["id"]
    res = client.post(f"/cases/{cid}/documents", files={"file": ("a.txt", io.BytesIO(b"x" * 10), "text/plain")}, headers=reviewer)
    assert res.status_code == 413


def test_path_traversal_filename_is_not_used_on_disk(client, reviewer):
    cid = create_case(client, reviewer)["id"]
    res = client.post(f"/cases/{cid}/documents",
                      files={"file": ("../../etc/evil.txt", b"Name: A B", "text/plain")}, headers=reviewer)
    assert res.status_code == 201
    assert res.json()["filename"] == "evil.txt"


def test_corrupt_pdf_marks_document_failed(client, reviewer):
    cid = create_case(client, reviewer)["id"]
    res = client.post(f"/cases/{cid}/documents", files={"file": ("broken.pdf", b"not a pdf", "application/pdf")}, headers=reviewer)
    assert res.status_code == 201
    detail = client.get(f"/cases/{cid}", headers=reviewer).json()
    assert detail["documents"][0]["status"] == "FAILED"
    actions = [e["action"] for e in client.get(f"/cases/{cid}/audit-log", headers=reviewer).json()]
    assert "DOCUMENT_FAILED" in actions
