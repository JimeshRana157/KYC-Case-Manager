import os
import tempfile
from pathlib import Path

# Must be set BEFORE the app is imported: the engine is created at import time.
os.environ["DATABASE_URL"] = "sqlite://"
os.environ["UPLOAD_DIR"] = tempfile.mkdtemp(prefix="kyc-test-uploads-")
os.environ["JWT_SECRET"] = "test-secret-test-secret-test-secret-123"
os.environ["ANTHROPIC_API_KEY"] = ""  # force the extractive Q&A path; never call a real API in tests

import pytest  # noqa: E402
from fastapi.testclient import TestClient  # noqa: E402

from app.database import Base, SessionLocal, engine  # noqa: E402
from app.main import app  # noqa: E402
from app.models import Role, User  # noqa: E402
from app.security import hash_password  # noqa: E402
from app.services.sanctions import seed_sanctions  # noqa: E402

SAMPLE_DIR = Path(__file__).resolve().parents[2] / "sample_data"
PASSWORD = "password123"


@pytest.fixture(autouse=True)
def fresh_db():
    Base.metadata.drop_all(engine)
    Base.metadata.create_all(engine)
    with SessionLocal() as db:
        seed_sanctions(db)
    yield


@pytest.fixture
def client():
    return TestClient(app)  # no `with`: skip the lifespan, we seed explicitly


def _make_user(email: str, role: Role) -> None:
    with SessionLocal() as db:
        db.add(User(email=email, password_hash=hash_password(PASSWORD), role=role.value))
        db.commit()


def _headers(client: TestClient, email: str) -> dict:
    res = client.post("/auth/login", data={"username": email, "password": PASSWORD})
    assert res.status_code == 200, res.text
    return {"Authorization": f"Bearer {res.json()['access_token']}"}


@pytest.fixture
def reviewer(client):
    _make_user("reviewer@example.com", Role.REVIEWER)
    return _headers(client, "reviewer@example.com")


@pytest.fixture
def admin(client):
    _make_user("admin@example.com", Role.ADMIN)
    return _headers(client, "admin@example.com")


def create_case(client, headers, name="Aarav Mehta") -> dict:
    res = client.post("/cases", json={"customer_name": name}, headers=headers)
    assert res.status_code == 201, res.text
    return res.json()


def upload_sample(client, headers, case_id: int, filename: str, doc_type: str = "ID"):
    path = SAMPLE_DIR / filename
    with open(path, "rb") as fh:
        return client.post(
            f"/cases/{case_id}/documents",
            files={"file": (filename, fh, "text/plain")},
            data={"doc_type": doc_type},
            headers=headers,
        )
