from datetime import date

from app.services.risk import Flag, evaluate, name_similarity, score_flags

TODAY = date(2026, 11, 25)
GOOD = {"name": "Aarav Mehta", "dob": "1999-03-14", "id_number": "EX-1", "expiry": "2032-08-30"}
SANCTIONS = ["Rodrigo Valmont Estrada", "Mei Lin Zhaoran"]


def codes(flags):
    return {f.rule_code for f in flags}


def test_clean_case_has_no_flags():
    flags = evaluate("Aarav Mehta", [("id.txt", GOOD)], SANCTIONS, today=TODAY)
    assert flags == []
    assert score_flags(flags) == (0, "LOW")


def test_expired_document():
    fields = {**GOOD, "expiry": "2022-01-15"}
    flags = evaluate("Aarav Mehta", [("id.txt", fields)], SANCTIONS, today=TODAY)
    assert codes(flags) == {"DOC_EXPIRED"}
    assert score_flags(flags) == (30, "MEDIUM")


def test_document_expiring_today_is_not_expired():
    fields = {**GOOD, "expiry": TODAY.isoformat()}
    assert evaluate("Aarav Mehta", [("id.txt", fields)], SANCTIONS, today=TODAY) == []


def test_name_mismatch_but_word_order_and_punctuation_are_ignored():
    assert "NAME_MISMATCH" in codes(evaluate("Aarav Mehta", [("id.txt", {**GOOD, "name": "Rohan Verma"})], SANCTIONS, TODAY))
    assert evaluate("Aarav Mehta", [("id.txt", {**GOOD, "name": "MEHTA, Aarav"})], SANCTIONS, TODAY) == []


def test_sanctions_match_uses_fuzzy_matching():
    fields = {**GOOD, "name": "Rodrigo Valmont Estrada"}
    flags = evaluate("Rodrigo Valmont Estrada", [("id.txt", fields)], SANCTIONS, today=TODAY)
    assert codes(flags) == {"SANCTIONS_MATCH"}
    # one-letter typo still caught
    typo = evaluate("Rodrigo Valmont Estrda", [], SANCTIONS, today=TODAY)
    assert codes(typo) == {"SANCTIONS_MATCH"}
    assert score_flags(flags) == (60, "HIGH")


def test_similar_but_different_name_is_not_a_sanctions_hit():
    assert evaluate("Rodrigo Smith", [], SANCTIONS, today=TODAY) == []


def test_sanctions_screening_also_checks_the_name_on_the_document():
    fields = {**GOOD, "name": "Mei Lin Zhaoran"}
    flags = evaluate("Aarav Mehta", [("id.txt", fields)], SANCTIONS, today=TODAY)
    assert codes(flags) == {"NAME_MISMATCH", "SANCTIONS_MATCH"}


def test_underage():
    fields = {**GOOD, "dob": "2012-05-01"}
    assert codes(evaluate("Aarav Mehta", [("id.txt", fields)], SANCTIONS, today=TODAY)) == {"UNDERAGE"}


def test_exactly_18_is_not_underage():
    fields = {**GOOD, "dob": "2008-11-25"}
    assert evaluate("Aarav Mehta", [("id.txt", fields)], SANCTIONS, today=TODAY) == []


def test_missing_fields():
    flags = evaluate("Aarav Mehta", [("bill.txt", {"name": "Aarav Mehta"})], SANCTIONS, today=TODAY)
    assert codes(flags) == {"MISSING_FIELDS"}


def test_score_is_capped_at_100_and_levels():
    flags = [Flag("A", 60, ""), Flag("B", 30, ""), Flag("C", 25, "")]
    assert score_flags(flags) == (100, "HIGH")
    assert score_flags([Flag("A", 29, "")]) == (29, "LOW")
    assert score_flags([Flag("A", 30, "")]) == (30, "MEDIUM")
    assert score_flags([Flag("A", 59, "")]) == (59, "MEDIUM")


def test_name_similarity_bounds():
    assert name_similarity("Aarav Mehta", "aarav  mehta") == 100
    assert name_similarity("Aarav Mehta", "Zzz Qqq") < 40
