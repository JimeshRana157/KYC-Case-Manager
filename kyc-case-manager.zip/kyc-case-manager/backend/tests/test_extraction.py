from datetime import date

import pytest

from app.services.extraction import extract_text, parse_date, parse_fields


@pytest.mark.parametrize(
    "raw,expected",
    [
        ("2030-01-31", date(2030, 1, 31)),
        ("31/01/2030", date(2030, 1, 31)),
        ("31-01-2030", date(2030, 1, 31)),
        ("31.01.2030", date(2030, 1, 31)),
        ("31 Jan 2030", date(2030, 1, 31)),
        ("31 January 2030", date(2030, 1, 31)),
        ("not a date", None),
        ("", None),
        (None, None),
    ],
)
def test_parse_date(raw, expected):
    assert parse_date(raw) == expected


def test_parse_fields_normalises_dates_and_handles_label_variants():
    text = "Name: Aarav Mehta\nDOB: 14/03/1999\nDocument No: EX-4821-7730\nValid until: 30 Aug 2032\n"
    assert parse_fields(text) == {
        "name": "Aarav Mehta",
        "dob": "1999-03-14",
        "id_number": "EX-4821-7730",
        "expiry": "2032-08-30",
    }


def test_parse_fields_skips_unparseable_dates_and_missing_labels():
    assert parse_fields("Full Name: A B\nExpiry Date: soon") == {"name": "A B"}
    assert parse_fields("nothing useful here") == {}


def test_extract_text_txt(tmp_path):
    f = tmp_path / "a.txt"
    f.write_text("Name: X Y")
    assert extract_text(str(f)) == "Name: X Y"


def test_extract_text_rejects_unknown_type(tmp_path):
    f = tmp_path / "a.exe"
    f.write_text("x")
    with pytest.raises(ValueError):
        extract_text(str(f))


def test_extract_text_pdf(tmp_path):
    # Minimal one-page PDF containing the text "Name: Pdf Person"
    body = b"BT /F1 12 Tf 72 720 Td (Name: Pdf Person) Tj ET"
    objs = [
        b"<< /Type /Catalog /Pages 2 0 R >>",
        b"<< /Type /Pages /Kids [3 0 R] /Count 1 >>",
        b"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Contents 4 0 R /Resources << /Font << /F1 5 0 R >> >> >>",
        b"<< /Length %d >>\nstream\n" % len(body) + body + b"\nendstream",
        b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>",
    ]
    out, offsets = b"%PDF-1.4\n", []
    for i, o in enumerate(objs, start=1):
        offsets.append(len(out))
        out += b"%d 0 obj\n" % i + o + b"\nendobj\n"
    xref = len(out)
    out += b"xref\n0 %d\n0000000000 65535 f \n" % (len(objs) + 1)
    out += b"".join(b"%010d 00000 n \n" % off for off in offsets)
    out += b"trailer\n<< /Size %d /Root 1 0 R >>\nstartxref\n%d\n%%%%EOF" % (len(objs) + 1, xref)
    pdf = tmp_path / "a.pdf"
    pdf.write_bytes(out)
    assert "Pdf Person" in extract_text(str(pdf))
