from tests.conftest import PASSWORD


def test_register_creates_reviewer_and_hides_password(client):
    res = client.post("/auth/register", json={"email": "New@Example.com", "password": PASSWORD})
    assert res.status_code == 201
    body = res.json()
    assert body["email"] == "new@example.com" and body["role"] == "reviewer"
    assert "password" not in body and "password_hash" not in body


def test_register_cannot_choose_admin_role(client):
    res = client.post("/auth/register", json={"email": "x@example.com", "password": PASSWORD, "role": "admin"})
    assert res.status_code == 201 and res.json()["role"] == "reviewer"


def test_register_duplicate_and_validation(client):
    payload = {"email": "a@example.com", "password": PASSWORD}
    assert client.post("/auth/register", json=payload).status_code == 201
    assert client.post("/auth/register", json=payload).status_code == 409
    assert client.post("/auth/register", json={"email": "bad", "password": PASSWORD}).status_code == 422
    assert client.post("/auth/register", json={"email": "b@example.com", "password": "short"}).status_code == 422


def test_login_success_and_failure(client):
    client.post("/auth/register", json={"email": "a@example.com", "password": PASSWORD})
    ok = client.post("/auth/login", data={"username": "a@example.com", "password": PASSWORD})
    assert ok.status_code == 200 and ok.json()["token_type"] == "bearer"
    assert client.post("/auth/login", data={"username": "a@example.com", "password": "wrong-password"}).status_code == 401
    assert client.post("/auth/login", data={"username": "nobody@example.com", "password": PASSWORD}).status_code == 401


def test_protected_routes_need_a_valid_token(client):
    assert client.get("/cases").status_code == 401
    assert client.get("/cases", headers={"Authorization": "Bearer garbage"}).status_code == 401


def test_me(client, reviewer):
    res = client.get("/auth/me", headers=reviewer)
    assert res.status_code == 200 and res.json()["email"] == "reviewer@example.com"


def test_user_list_is_admin_only(client, reviewer, admin):
    assert client.get("/auth/users", headers=reviewer).status_code == 403
    res = client.get("/auth/users", headers=admin)
    assert res.status_code == 200 and len(res.json()) == 2


def test_health_and_rules_are_public(client):
    assert client.get("/health").json() == {"status": "ok"}
    codes = {r["code"] for r in client.get("/rules").json()}
    assert {"SANCTIONS_MATCH", "DOC_EXPIRED", "NAME_MISMATCH"} <= codes
