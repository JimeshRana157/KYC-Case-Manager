from app.config import settings
from app.services import qa
from tests.conftest import create_case, upload_sample


def test_ask_returns_cited_sources_with_flags(client, reviewer):
    cid = create_case(client, reviewer)["id"]
    upload_sample(client, reviewer, cid, "expired_id.txt")
    res = client.post(f"/cases/{cid}/ask", json={"question": "Why was this case flagged?"}, headers=reviewer)
    assert res.status_code == 200
    body = res.json()
    assert body["mode"] == "extractive"
    assert body["sources"][0]["id"] == "S1"
    assert "DOC_EXPIRED" in body["sources"][0]["text"]
    assert "[S1]" in body["answer"]


def test_ask_retrieves_relevant_document_chunk(client, reviewer):
    cid = create_case(client, reviewer)["id"]
    upload_sample(client, reviewer, cid, "valid_id.txt")
    body = client.post(f"/cases/{cid}/ask", json={"question": "What is the ID number?"}, headers=reviewer).json()
    assert any("EX-4821-7730" in s["text"] for s in body["sources"])


def test_ask_works_on_a_case_without_documents(client, reviewer):
    cid = create_case(client, reviewer)["id"]
    body = client.post(f"/cases/{cid}/ask", json={"question": "Any documents uploaded?"}, headers=reviewer).json()
    assert [s["id"] for s in body["sources"]] == ["S1"]


def test_ask_validation_and_404(client, reviewer):
    cid = create_case(client, reviewer)["id"]
    assert client.post(f"/cases/{cid}/ask", json={"question": "?"}, headers=reviewer).status_code == 422
    assert client.post("/cases/999/ask", json={"question": "hello there"}, headers=reviewer).status_code == 404


def test_llm_failure_falls_back_to_extractive(client, reviewer, monkeypatch):
    monkeypatch.setattr(settings, "anthropic_api_key", "fake-key")

    def boom(*_a, **_k):
        raise RuntimeError("network down")

    monkeypatch.setattr(qa, "_llm_answer", boom)
    cid = create_case(client, reviewer)["id"]
    body = client.post(f"/cases/{cid}/ask", json={"question": "Summarise this case"}, headers=reviewer).json()
    assert body["mode"] == "extractive"


def test_llm_answer_is_used_when_available(client, reviewer, monkeypatch):
    monkeypatch.setattr(settings, "anthropic_api_key", "fake-key")
    monkeypatch.setattr(qa, "_llm_answer", lambda question, sources: "Grounded answer [S1]")
    cid = create_case(client, reviewer)["id"]
    body = client.post(f"/cases/{cid}/ask", json={"question": "Summarise this case"}, headers=reviewer).json()
    assert (body["mode"], body["answer"]) == ("llm", "Grounded answer [S1]")
