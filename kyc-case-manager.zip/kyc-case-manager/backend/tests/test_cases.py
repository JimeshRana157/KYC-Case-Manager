from tests.conftest import create_case, upload_sample


def set_status(client, headers, case_id, status, note=None):
    return client.patch(f"/cases/{case_id}/status", json={"status": status, "note": note}, headers=headers)


def test_create_and_get_case(client, reviewer):
    case = create_case(client, reviewer)
    assert case["status"] == "PENDING" and case["risk_score"] == 0
    detail = client.get(f"/cases/{case['id']}", headers=reviewer).json()
    assert detail["customer_name"] == "Aarav Mehta" and detail["documents"] == [] and detail["flags"] == []
    assert client.get("/cases/999", headers=reviewer).status_code == 404


def test_create_case_validation(client, reviewer):
    assert client.post("/cases", json={"customer_name": "A"}, headers=reviewer).status_code == 422
    assert client.post("/cases", json={"customer_name": "Ok Name", "customer_email": "nope"}, headers=reviewer).status_code == 422


def test_list_filters_search_and_pagination(client, reviewer):
    for name in ["Aarav Mehta", "Rohan Verma", "Priya Shah"]:
        create_case(client, reviewer, name)
    first = client.get("/cases?page_size=2", headers=reviewer).json()
    assert first["total"] == 3 and len(first["items"]) == 2
    assert first["items"][0]["customer_name"] == "Priya Shah"  # newest first
    assert len(client.get("/cases?page_size=2&page=2", headers=reviewer).json()["items"]) == 1
    assert client.get("/cases?q=rohan", headers=reviewer).json()["total"] == 1
    assert client.get("/cases?status=APPROVED", headers=reviewer).json()["total"] == 0
    assert client.get("/cases?status=NOPE", headers=reviewer).status_code == 422
    assert client.get("/cases?risk_min=50", headers=reviewer).json()["total"] == 0


def test_status_workflow_and_audit_log(client, reviewer):
    cid = create_case(client, reviewer)["id"]
    assert set_status(client, reviewer, cid, "IN_REVIEW").status_code == 200
    assert set_status(client, reviewer, cid, "APPROVED").json()["status"] == "APPROVED"

    log = client.get(f"/cases/{cid}/audit-log", headers=reviewer).json()
    assert [e["action"] for e in log] == ["CASE_CREATED", "STATUS_CHANGED", "STATUS_CHANGED"]
    assert (log[-1]["old_status"], log[-1]["new_status"]) == ("IN_REVIEW", "APPROVED")
    assert log[-1]["user_email"] == "reviewer@example.com"


def test_invalid_transitions_are_rejected(client, reviewer):
    cid = create_case(client, reviewer)["id"]
    res = set_status(client, reviewer, cid, "APPROVED")  # PENDING -> APPROVED not allowed
    assert res.status_code == 400
    assert set_status(client, reviewer, cid, "PENDING").status_code == 400  # same state


def test_rejection_requires_a_note(client, reviewer):
    cid = create_case(client, reviewer)["id"]
    set_status(client, reviewer, cid, "IN_REVIEW")
    assert set_status(client, reviewer, cid, "REJECTED").status_code == 400
    assert set_status(client, reviewer, cid, "REJECTED", note="   ").status_code == 400
    assert set_status(client, reviewer, cid, "REJECTED", note="Forged document").status_code == 200


def test_only_admin_can_reopen_decided_case(client, reviewer, admin):
    cid = create_case(client, reviewer)["id"]
    set_status(client, reviewer, cid, "IN_REVIEW")
    set_status(client, reviewer, cid, "APPROVED")
    assert set_status(client, reviewer, cid, "IN_REVIEW").status_code == 403
    assert set_status(client, admin, cid, "IN_REVIEW").status_code == 200


def test_high_risk_case_needs_admin_to_approve(client, reviewer, admin):
    cid = create_case(client, reviewer, "Rodrigo Valmont Estrada")["id"]
    upload_sample(client, reviewer, cid, "sanctions_hit_id.txt")
    assert client.get(f"/cases/{cid}", headers=reviewer).json()["risk_level"] == "HIGH"
    set_status(client, reviewer, cid, "IN_REVIEW")
    assert set_status(client, reviewer, cid, "APPROVED").status_code == 403
    assert set_status(client, admin, cid, "APPROVED").status_code == 200


def test_assign_is_admin_only(client, reviewer, admin):
    cid = create_case(client, reviewer)["id"]
    me = client.get("/auth/me", headers=reviewer).json()
    assert client.patch(f"/cases/{cid}/assign", json={"user_id": me["id"]}, headers=reviewer).status_code == 403
    res = client.patch(f"/cases/{cid}/assign", json={"user_id": me["id"]}, headers=admin)
    assert res.status_code == 200 and res.json()["assignee_email"] == "reviewer@example.com"
    assert client.patch(f"/cases/{cid}/assign", json={"user_id": 12345}, headers=admin).status_code == 404
    assert client.patch(f"/cases/{cid}/assign", json={"user_id": None}, headers=admin).json()["assignee_email"] is None


def test_delete_is_admin_only(client, reviewer, admin):
    cid = create_case(client, reviewer)["id"]
    assert client.delete(f"/cases/{cid}", headers=reviewer).status_code == 403
    assert client.delete(f"/cases/{cid}", headers=admin).status_code == 204
    assert client.get(f"/cases/{cid}", headers=admin).status_code == 404


def test_stats(client, reviewer):
    a = create_case(client, reviewer)["id"]
    create_case(client, reviewer, "Rohan Verma")
    set_status(client, reviewer, a, "IN_REVIEW")
    stats = client.get("/cases/stats", headers=reviewer).json()
    assert stats == {"total": 2, "pending": 1, "in_review": 1, "approved": 0, "rejected": 0, "high_risk": 0}
