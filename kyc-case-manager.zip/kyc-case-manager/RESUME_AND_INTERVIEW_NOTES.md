# Resume entry and interview notes (not part of the app; delete before publishing if you like)

## Resume entry
Fill in the links. The numbers below were measured on this codebase; re-check them if you change it.

**KYC Case Manager** | Python, FastAPI, PostgreSQL, React, TypeScript, Docker, GitHub Actions | [GitHub] [Live Demo]
- Built a full-stack KYC case-management app: JWT role-based access (admin/reviewer), document upload, review workflow with an audit trail, and 18 REST endpoints backed by PostgreSQL and Alembic migrations.
- Designed a rule-based risk engine (sanctions fuzzy match, expiry, name mismatch, age, missing fields) as pure, unit-tested functions; 60 pytest tests at ~96% coverage.
- Built an async document pipeline (PDF/OCR extraction → field parsing → scoring) and an "Ask about this case" feature using BM25 retrieval with cited sources and an LLM fallback path.
- Containerised with Docker Compose and added GitHub Actions CI (tests with coverage gate, frontend build, image build).

Shorter version for AiPrise / fintech roles: lead with "KYC/compliance workflow, sanctions screening, audit trail, role-based approvals".
Shorter version for AI roles (MediaMint, InteligenAI): lead with "retrieval-grounded Q&A, extraction pipeline, LLM integration with safe fallback".

## Be ready to explain (you will be asked)
1. **Why PostgreSQL, not SQLite?** Concurrent writers, real pooling, production parity. SQLite only for tests. (I hit a real bug here: SQLAlchemy 2.1 defaulted file-SQLite to a single shared connection, which crashed under concurrent requests. Fixed by using a real pool and pinning SQLAlchemy 2.0.)
2. **How does JWT auth work?** Login verifies a bcrypt hash and issues a signed token with `sub`, `role`, `exp`; a dependency decodes it on every request and loads the user.
3. **Why a background task for extraction?** OCR/PDF parsing is slow; the upload returns immediately and the UI polls until the document is `PROCESSED`.
4. **How do you limit false positives in name matching?** Normalisation (case, punctuation, word order) plus a similarity threshold. 90% for sanctions, 85% for mismatch, tuneable constants.
5. **How do you stop the LLM making things up?** It only sees the retrieved chunks of one case, the prompt says to answer only from sources and cite them, and it can't make the decision.
6. **Why not rank_bm25?** It gave zero/negative scores on tiny corpora (a single case has only a few chunks), so retrieval returned nothing. I wrote a small BM25 with a positive IDF and tested it.
7. **How would you scale it?** Queue workers for extraction, object storage for files, read replicas / indexes on `status`, `risk_score`, cursor pagination, cache sanctions list.
8. **Security choices?** Passwords hashed with bcrypt, public sign-up can only create reviewers, upload type/size validation, files stored under random names (no path traversal), admin-only destructive actions.

## Before you publish
- Change `JWT_SECRET` and the default admin password; never commit `.env`.
- Add 2 screenshots to the README (already included in `docs/`).
- Deploy it (Render/Railway for the backend + Postgres, Vercel for the frontend) and put the live link on your resume.
- Read every file once so you can explain it. Interviewers will ask about the code.
